const {getUserById} = require('./user.js');
const fs = require('fs');

function getMatchedBots(userId) {
    const user = getUserById(userId);
    if (user == null) {
        console.log("User not found");
        return null;
    }
    console.log("User found:", user);

    // this gets a list of bots that the user has interacted with.
    const bots = JSON.parse(fs.readFileSync('./static/bots.json', 'utf8'));
    console.log("All bots:", bots);

    // const matchedBots = bots.map((bot) => {
    //     const hasLikes = user.likes && user.likes.length > 0;
    //     const hasDislikes = user.dislikes && user.dislikes.length > 0;

    //     if (hasLikes && user.likes.includes(bot.id)) {
    //         return { ...bot, interaction: 'like' };
    //     } else if (hasDislikes && user.dislikes.includes(bot.id)) {
    //         return { ...bot, interaction: 'dislike' };
    //     } else {
    //         return null;
    //     }
    // }).filter(bot => bot !== null);

    // console.log("Matched bots:", matchedBots);
    return bots;

    return matchedBots;
}


module.exports = {getMatchedBots};
