const {v4: uuidv4} = require('uuid');
const fs = require('fs');
const path = require('path');


function addSession(userID, userAgent, expiresAt) {
    const sessionID = uuidv4();
    file = fs.readFileSync('./users/' + userID + ".json");
    const userData = JSON.parse(file);
    // add it to the sessions array
    userData.sessions.push({
        id: sessionID,
        userAgent: userAgent,
        expiresAt: expiresAt
    });
    fs.writeFileSync('./users/' + userID + ".json", JSON.stringify(userData));
    return sessionID;
}

module.exports = {addSession};