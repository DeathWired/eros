const crypto = require('crypto');

const SALT_LENGTH = 16;
const HASH_ITERATIONS = 1000;
const HASH_LENGTH = 64;
const HASH_ALGORITHM = 'sha512';
const SALT = crypto.randomBytes(SALT_LENGTH).toString();

function hashPassword(password) {
    const salt = SALT;
    const hash = crypto.pbkdf2Sync(password, salt, HASH_ITERATIONS, HASH_LENGTH, HASH_ALGORITHM).toString('hex');
    return {
        salt: salt,
        hash: hash
    };
}

function checkPassword(password, storedHash, salt) {
    const hash = crypto.pbkdf2Sync(password, salt, HASH_ITERATIONS, HASH_LENGTH, HASH_ALGORITHM).toString('hex');
    console.log({"newHash": hash, "storedHash": storedHash})
    return hash === storedHash;
}


module.exports = {hashPassword, checkPassword}