const { hashPassword, checkPassword } = require("./sheasby-crypto");
const { v4: uuidv4 } = require('uuid');
const fs = require('fs');
const path = require('path');

class User{
    constructor(firstName, lastName, email, username, password){
        this.id = uuidv4();
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.preferences = [];
        this.profile = {};
        this.bio = "";
        this.sessions = [];
        this.username = username;
        this.rejected = [];
        this.liked = [];
        this.blocked = [];
        this.passSalt = hashPassword(password).salt;
        this.passHash = hashPassword(password).hash;
    }
}


function getUser(email) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (userData.email === email) {
                    return userData;
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function userExists(email) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (userData.email === email) {
                    return true;
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function getUserByUsername(givenUsername) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (userData.username === givenUsername) {
                    return userData;
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function getUserById(givenId) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (userData.id === givenId) {
                    return userData;
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function validateEmail(email) {
    const emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (email !== '' && email.match(emailFormat)) { 
        return true; 
    }
    return false;
}

function validatePassword(password) {
    if (password.length < 7) {
        return false;
    }
    if (password.length > 100) {
        return false;
    }
    return true
}

function getUserBySessionID(sessionID) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                for (const session of userData.sessions) {
                    if (session.id === sessionID) {
                        return userData;
                    }
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function updateUser(user) {
    fs.writeFileSync('./users/' + user.id + ".json", JSON.stringify(user));
}

function saveUser(user) {
    fs.writeFileSync('./users/' + user.id + ".json", JSON.stringify(user));
}

module.exports = {User, getUser, userExists, getUserByUsername, getUserBySessionID, getUserById, validateEmail, validatePassword, saveUser, updateUser};