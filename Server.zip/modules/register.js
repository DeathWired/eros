// functions for registration
const fs = require('fs');
const re = require('re');
const path = require('path');

function userExists(email) {
    const usersDir = './users';
    try {
        const files = fs.readdirSync(usersDir);
        for (const file of files) {
            if (path.extname(file) === '.json') {
                const filePath = path.join(usersDir, file);
                const userData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
                if (userData.email === email) {
                    return true;
                }
            }
        }
    } catch (error) {
        console.error(error);
    }
    return false;
}

function validateEmail(email) {
    const emailFormat = /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/;
    if (email !== '' && email.match(emailFormat)) { 
        return true; 
    }
    return false;
}

function validatePassword(password) {
    if (password.length < 7) {
        return false;
    }
    if (password.length > 100) {
        return false;
    }
    return true
}

function saveUser(user) {
    fs.writeFileSync('./users/' + user.id + ".json", JSON.stringify(user));
}

module.exports = {userExists, validateEmail, validatePassword, saveUser}