const fs = require('fs');
const express = require('express');
const crypto = require('crypto');
const cors = require('cors')
const BASEURL = "/api"
const bodyparser = require('body-parser');

const {User, getUserBySessionID, userExists, getUserByUsername, validateEmail, validatePassword, saveUser, updateUser} = require('./modules/user.js')
const { checkPassword } = require('./modules/sheasby-crypto.js');
const { v4: uuidv4 } = require('uuid');
const { addSession } = require('./modules/session.js');
const { getMatchedBots } = require('./modules/matchmaking.js');


const app = express();
app.use(bodyparser.json());
app.use(cors({origin: '*'}));



app.use(express.urlencoded({ extended: true }));
const port = 80;

function jsonError(res, code, friendlyMessage) {
    return res.status(code).json({error: friendlyMessage});
}

app.get(BASEURL + '/', (req, res) => {
    res.send('Ok');
});


app.post(BASEURL + '/register', (req, res) => {
    try {
    console.log(req.body.firstName, req.body.lastName, req.body.email, req.body.username ,req.body.password)
        if (req.body.firstName == null || req.body.lastName == null || req.body.email == null || req.body.password == null || req.body.username == null) {
            return jsonError(res, 400, "Missing required information.");
        }
    } catch (error) {
        return jsonError(res, 400, "Invalid request.");
    }
    if (userExists(req.body.email)) {
         return jsonError(res, 400, "User already exists");
    }
    if (!validateEmail(req.body.email) || !validatePassword(req.body.password)) {
        return jsonError(res, 400, "Invalid email or password.");
    }
    const userID = uuidv4();
    saveUser(new User(req.body.firstName, req.body.lastName, req.body.email, req.body.username, req.body.password));
    const user = getUserByUsername(req.body.username);
    const sessionID = addSession(user.id,  Date.now() + 1000 * 60 * 60 * 24 * 60);
    return res.status(200).json({"sessionID": sessionID})
});

app.post(BASEURL + '/login', (req, res) => {
    try {
        if (req.body.username == null || req.body.password == null) {
            return jsonError(res, 400, "Missing required information.");
        }
    } catch (error) {
        return jsonError(res, 400, "Invalid request.");
    }
    const user = getUserByUsername(req.body.username);
    console.log(user)
    if (!user) {
        return jsonError(res, 400, "User does not exist.");
    }
    if (!checkPassword(req.body.password, user.passHash, user.passSalt)) {
        return jsonError(res, 400, "Incorrect password.");
    }
    const sessionID = addSession(user.id,  Date.now() + 1000 * 60 * 60 * 24 * 7);
    return res.status(200).json({"sessionID": sessionID})
});

app.get(BASEURL + "/getmatches", (req, res) => {
    let sessionId = null;
    const authHeader = req.headers.authorization;
    console.log(authHeader)
    if (authHeader) {
        sessionId = authHeader
    }

    if (!sessionId) {
    return jsonError(res, 400, "Missing session cookie or authorization header.");
    }
    const user = getUserBySessionID(sessionId);
    // no user
    if (!user) {
        return jsonError(res, 400, "Invalid session");
    }
    // return the user's matches
    return res.status(200).json(getMatchedBots(user.id));

});

app.post(BASEURL + "/saveprefs", (req, res) => {
    let sessionId = null;
    const authHeader = req.headers.authorization;
    console.log(authHeader)
    if (authHeader) {
        sessionId = authHeader
    }

    if (!sessionId) {
    return jsonError(res, 400, "Missing session cookie or authorization header.");
    }
    const user = getUserBySessionID(sessionId);
    if (!user) {
        return jsonError(res, 400, "Invalid session");
    }
    // this is not a good idea but we have no times
    prefs = JSON.parse(req.body)
    user.preferences = prefs;
    updateUser(user);
    return res.status(200).json({success: true})
});

app.get(BASEURL + "/getprefs", (req, res) => {
    let sessionId = null;
    const authHeader = req.headers.authorization;
    console.log(authHeader)
    if (authHeader) {
        sessionId = authHeader
    }

    if (!sessionId) {
    return jsonError(res, 400, "Missing session cookie or authorization header.");
    }
    const user = getUserBySessionID(sessionId);
    if (!user) {
        return jsonError(res, 400, "Invalid session");
    }
    return res.status(200).json(user.preferences)
});

app.listen(port, "0.0.0.0", () => {
    console.log(`Example app listening at http://localhost:${port}`);
});
